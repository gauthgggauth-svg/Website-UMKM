from http.server import BaseHTTPRequestHandler
import json, html, re
from urllib.parse import quote

class handler(BaseHTTPRequestHandler):
    def _send(self, status, payload):
        body=json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin","*")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self._send(200, {"ok": True})

    def do_POST(self):
        try:
            n=int(self.headers.get("Content-Length","0"))
            data=json.loads(self.rfile.read(n) or b"{}")
            required=["name","tagline","description","cta","whatsapp","color","style","image"]
            if any(not str(data.get(k,"")).strip() for k in required):
                return self._send(400, {"error":"Semua field wajib diisi."})
            if not re.match(r"^#[0-9a-fA-F]{6}$", data["color"]):
                return self._send(400, {"error":"Warna harus format hex, contoh #7c3aed."})
            clean={k:html.escape(str(data[k]).strip(), quote=True) for k in required}
            phone=re.sub(r"\D","",str(data["whatsapp"]))
            wa=f"https://wa.me/{phone}?text={quote('Halo '+str(data['name'])+', saya ingin pesan.')}"
            radius={"bold":"28px","warm":"18px","clean":"14px"}.get(data["style"],"14px")
            out=f"""<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{clean['name']}</title>
<style>:root{{--c:{clean['color']}}}*{{box-sizing:border-box}}body{{margin:0;font-family:system-ui,sans-serif;color:#18181b}}.nav,.hero,.about-in{{max-width:1100px;margin:auto}}.nav{{padding:22px 24px;display:flex;justify-content:space-between}}.hero{{padding:70px 24px;display:grid;grid-template-columns:1fr 1fr;gap:50px;align-items:center}}.hero h1{{font-size:clamp(42px,6vw,76px);line-height:1;margin:15px 0}}.hero p,.about p{{color:#52525b;line-height:1.8;font-size:18px}}.cta{{display:inline-block;background:var(--c);color:white;padding:14px 20px;border-radius:{radius};text-decoration:none;font-weight:800}}.photo{{height:500px;border-radius:{radius};background:url('{clean['image']}') center/cover}}.about{{background:#fafafa;padding:70px 24px;text-align:center}}.foot{{padding:35px;text-align:center;color:#71717a}}@media(max-width:760px){{.hero{{grid-template-columns:1fr}}.photo{{height:320px}}}}</style></head>
<body><nav class="nav"><b>{clean['name']}</b><a href="{wa}" target="_blank">{clean['cta']}</a></nav><section class="hero"><div><small style="color:{clean['color']};font-weight:800">UMKM LOKAL</small><h1>{clean['tagline']}</h1><p>{clean['description']}</p><a class="cta" href="{wa}" target="_blank">{clean['cta']} →</a></div><div class="photo"></div></section><section class="about"><div class="about-in"><h2>Kenapa pilih {clean['name']}?</h2><p>Kualitas, pelayanan ramah, dan pengalaman terbaik untuk setiap pelanggan.</p></div></section><footer class="foot">© 2026 {clean['name']}</footer></body></html>"""
            self._send(200, {"ok":True,"html":out})
        except Exception as e:
            self._send(500, {"error":"Server error: "+str(e)})
