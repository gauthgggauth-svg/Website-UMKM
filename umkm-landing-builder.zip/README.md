# UMKM Landing Builder

Website builder sederhana untuk membuat landing page UMKM.

## Stack
- HTML + CSS + JavaScript
- Python Serverless Function
- Vercel

## Jalankan lokal
Buka `index.html` untuk preview frontend. Untuk menguji API Python secara lokal, gunakan Vercel CLI:
```bash
npm i -g vercel
vercel dev
```

## Deploy
1. Upload folder ini ke GitHub.
2. Import repository di Vercel.
3. Framework Preset: Other.
4. Deploy.

Endpoint: `POST /api/generate`

Body JSON:
`name, tagline, description, cta, whatsapp, color, style, image`
