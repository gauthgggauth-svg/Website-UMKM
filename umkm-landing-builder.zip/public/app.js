const $=id=>document.getElementById(id);
const fields=["name","tagline","description","cta","whatsapp","color","style","image"];
function data(){return Object.fromEntries(fields.map(k=>[k,$(k).value]));}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
function landing(d){
 const phone=(d.whatsapp||"").replace(/\D/g,"");
 const wa=phone?`https://wa.me/${phone}?text=${encodeURIComponent("Halo "+d.name+", saya ingin pesan.")}":"#`;
 const radius=d.style==="bold"?"28px":d.style==="warm"?"18px":"14px";
 return `<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(d.name)}</title>
 <style>:root{--c:${d.color}}*{box-sizing:border-box}body{margin:0;font-family:Inter,system-ui,sans-serif;color:#18181b;background:#fff}.nav{max-width:1100px;margin:auto;padding:22px 24px;display:flex;justify-content:space-between;align-items:center}.logo{font-weight:900}.nav a{color:#18181b;text-decoration:none;font-weight:700}.hero{max-width:1100px;margin:auto;padding:55px 24px 85px;display:grid;grid-template-columns:1.05fr .95fr;gap:55px;align-items:center}.eyebrow{color:var(--c);font-weight:900;letter-spacing:.1em;text-transform:uppercase;font-size:12px}.hero h1{font-size:clamp(42px,6vw,76px);line-height:.98;margin:14px 0 20px;letter-spacing:-.04em}.hero p{font-size:18px;line-height:1.7;color:#52525b;max-width:600px}.cta{display:inline-block;margin-top:15px;padding:14px 20px;border-radius:${radius};background:var(--c);color:white;text-decoration:none;font-weight:850}.photo{height:520px;border-radius:${radius};background:url('${d.image}') center/cover;box-shadow:0 25px 70px #0002}.about{background:#fafafa;padding:75px 24px}.about-in{max-width:900px;margin:auto;text-align:center}.about h2{font-size:38px;margin:0 0 12px}.about p{color:#52525b;line-height:1.8}.foot{padding:35px 24px;text-align:center;color:#71717a;font-size:13px}@media(max-width:760px){.hero{grid-template-columns:1fr;padding-top:30px}.photo{height:330px}.nav{padding:18px 20px}.hero h1{font-size:48px}}</style></head>
 <body><nav class="nav"><div class="logo">${escapeHtml(d.name)}</div><a href="${wa}" target="_blank">${escapeHtml(d.cta)}</a></nav>
 <main><section class="hero"><div><div class="eyebrow">UMKM lokal</div><h1>${escapeHtml(d.tagline)}</h1><p>${escapeHtml(d.description)}</p><a class="cta" href="${wa}" target="_blank">${escapeHtml(d.cta)} →</a></div><div class="photo"></div></section>
 <section class="about"><div class="about-in"><h2>Kenapa pilih ${escapeHtml(d.name)}?</h2><p>Kami mengutamakan kualitas, pelayanan ramah, dan pengalaman terbaik untuk setiap pelanggan.</p></div></section></main>
 <footer class="foot">© ${new Date().getFullYear()} ${escapeHtml(d.name)} · Dibuat dengan UMKM Landing Builder</footer></body></html>`;
}
function render(){const d=data(); $("preview").srcdoc=landing(d); $("status").textContent="Auto-saved preview";}
fields.forEach(k=>$(k).addEventListener("input",render)); $("style").addEventListener("change",render);
$("resetBtn").onclick=()=>{location.reload()};
$("generateBtn").onclick=async()=>{const d=data();$("status").textContent="Generating…";try{const r=await fetch("/api/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(d)});const j=await r.json();if(!r.ok)throw new Error(j.error||"Gagal");const blob=new Blob([j.html],{type:"text/html"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=(d.name||"landing-page").toLowerCase().replace(/[^a-z0-9]+/g,"-")+".html";a.click();$("status").textContent="HTML downloaded";}catch(e){$("status").textContent="Backend error";alert(e.message)}};
render();